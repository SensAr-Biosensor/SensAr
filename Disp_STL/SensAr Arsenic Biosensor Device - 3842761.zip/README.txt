SensAr Arsenic Biosensor Device by javiergasulla on Thingiverse: https://www.thingiverse.com/thing:3842761

Summary:
SensAr is an arsenic biosensor based on microfluidic paper device. The parts placed here are the gasket that contains the paper circuit.
